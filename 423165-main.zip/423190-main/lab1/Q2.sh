 # Create a subdirectory in the directory created.
 #!/bin/bash
cd directory
mkdir directory1
