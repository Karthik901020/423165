# Display the calendar for the current month.
#!/bin/bash
cal
