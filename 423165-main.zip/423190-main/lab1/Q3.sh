# Change your current directory to the subdirectory.
#!/bin/bash
cd directory
