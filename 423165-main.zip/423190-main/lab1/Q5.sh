# Get a directory listing of the parent directory.
#!/bin/bash
ls . .
