# Create a directory.
#!/bin/bash
mkdir directory

