#List all files in the current directory with a .txt extension.
#!/bin/bash
ls a**.txt
