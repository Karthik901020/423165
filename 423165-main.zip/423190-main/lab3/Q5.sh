#List files in the current directory ending with .log, where the second character is a number (e.g.,a1.log).
#!/bin/bash
ls ?[0-9].log
