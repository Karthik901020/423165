#List all files in the current directory that start with the letter a.
#!/bin/bash
ls a*
