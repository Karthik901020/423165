#Find all files in the current directory whose names have exactly five characters.
#!/bin/bash
find -name "?????"
