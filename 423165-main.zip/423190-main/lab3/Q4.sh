#List files in the current directory that start with any letter between b and e.
#!/bin/bash
ls b**e
