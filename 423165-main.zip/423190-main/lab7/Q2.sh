# Q2) Extract all files from file.tar
#!/bin/bash
echo "Extracting all files from file.tar..."
tar -xvf file.tar
