# Q5) Create a compressed archive named myarchive.tar.gz from the 'myfolder' directory
#!/bin/bash
echo "Creating myarchive.tar.gz from myfolder directory..."
tar -cvzf myarchive.tar.gz myfolder
