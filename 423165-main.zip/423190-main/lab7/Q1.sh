# Q1) Archive all .c files into file.tar
#!/bin/bash
echo "Creating file.tar with all .c files..."
tar -cvf file.tar *.c

