# Q4) Extract Cfiles.tar.gz
#!/bin/bash
echo "Extracting Cfiles.tar.gz..."
tar -xvzf Cfiles.tar.gz
