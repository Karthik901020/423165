#Display the time in 12-Hour and 24 Hour Notations.
#!/bin/bash
date "+%I:%M:%S %p"

date "+%H:%M:%S"

