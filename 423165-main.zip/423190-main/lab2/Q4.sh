# Display the Current Date and Current Time.
#!/bin/bash
date "+%Y-%m-%d"

