# Display the message “GOOD MORNING” in enlarged characters.
#!/bin/bash
banner Good Morning
