#Obtain the following results
#(i) To print the name of operating system
#(ii) To print the login name
#(iii) To print the host name
#!/bin/bash
uname
users
hostname
