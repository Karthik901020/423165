#Find all lines containing the word &quot;error&quot; in a log file (log.txt).
#!/bin/bash
echo "Q1) Lines with the word 'error' in log.txt:"
grep "error" log.txt
